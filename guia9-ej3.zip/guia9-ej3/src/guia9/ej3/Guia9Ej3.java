/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia9.ej3;
import static service.ArregloService.*;
/**
 *
 * @author Usuario
 */
public class Guia9Ej3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] A=new int[50];
        int[] B=new int[20];
        
        inicializarA(A);
        mostrar(A);
        ordenar(A);
        mostrar(A);
        inicializarB(A,B);
        mostrar(B);
        

        
    }
    
}
