/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.util.Arrays;

/**
 *
 * @author Usuario
 */
public class ArregloService {
    public static void inicializarA(int[] A){
        for (int i = 0; i < A.length; i++) {
            A[i] = (int) (Math.random() * 10 + 1); // inicializar con número aleatorios entre 0 y 10
        }
    }
    
    public static void mostrar(int[] A){
        for (int i = 0; i < A.length; i++) {
            System.out.print("[" + A[i] + "]");
        }
        System.out.println(" ");
    }
    
    public static void ordenar(int[] A){
        Arrays.sort(A);
    }
    
    public static void inicializarB(int [] A, int [] B){
        System.arraycopy(A, 0, B, 0, 10);
        Arrays.fill(B,10,20,1);
    }
    
}
