package guia8;

import Entidades.Persona;
import Servicio.PersonaServicio;

/**
 *
 * @author mer22
 */
public class Guia8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Persona p1 = new Persona();
        Persona p2 = new Persona();
        Persona p3 = new Persona();
        Persona p4 = new Persona();
        PersonaServicio ps1 = new PersonaServicio();
        System.out.println("Cargar persona 1");
        ps1.crearPersona(p1);
//        System.out.println("Cargar persona 2");
//        ps1.crearPersona(p2);
//        System.out.println("Cargar persona 3");
//        ps1.crearPersona(p3);
//        System.out.println("Cargar persona 4");
//        ps1.crearPersona(p4);

        System.out.println("Calculando IMC de persona 1");

        ps1.leerImc(ps1.calcularIMC(p1));
        System.out.println("Calculando IMC de persona 2");
//        ps1.leerImc(ps1.calcularIMC(p2));
//        System.out.println("Calculando IMC de persona 3");
//        ps1.leerImc(ps1.calcularIMC(p3));
//        System.out.println("Calculando IMC de persona 4");
//        ps1.leerImc(ps1.calcularIMC(p4));

        System.out.println("La persona 1 es mayor de edad: " + ps1.esMayorDeEdad(p1));
//        System.out.println("La persona 2 es mayor de edad: " + ps1.esMayorDeEdad(p2));
//        System.out.println("La persona 3 es mayor de edad: " + ps1.esMayorDeEdad(p3));
//        System.out.println("La persona 4 es mayor de edad: " + ps1.esMayorDeEdad(p4));

    }

}
