/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicio;

import Entidades.Persona;
import java.util.Scanner;

/**
 *
 * @author mer22
 */
public class PersonaServicio {

    public boolean esMayorDeEdad(Persona persona1) {
        boolean esMayor = false;
        if (persona1.getEdad() >= 18) {
            esMayor = true;
        }
        return esMayor;
    }
    private Scanner leerserv = new Scanner(System.in).useDelimiter("\n");

    public void crearPersona(Persona persona1) {
        System.out.println("Ingrese su nombre");
        persona1.setNombre(leerserv.next());
        System.out.println("Ingrese su edad");
        persona1.setEdad(leerserv.nextInt());
        System.out.println("Ingrese su sexo: M - H - O");
        do {
            persona1.setSexo(leerserv.next());
            
            if ((!(persona1.getSexo().equalsIgnoreCase("m"))) && (!(persona1.getSexo().equalsIgnoreCase("h"))) && (!(persona1.getSexo().equalsIgnoreCase("o")))) {
                System.out.println("Incorrecto. Ingrese un caracter correcto: h - m - o");
            }
        } while ((!(persona1.getSexo().equalsIgnoreCase("m"))) && (!(persona1.getSexo().equalsIgnoreCase("h"))) && (!(persona1.getSexo().equalsIgnoreCase("o")))) ;
        

        System.out.println("Ingrese su altura");
        persona1.setAltura(leerserv.nextDouble());
        System.out.println("Ingrese su peso");
        persona1.setPeso(leerserv.nextDouble());

    }

    public int calcularIMC(Persona persona1) {
        //(peso en kg/(altura^2 en mt2))
        int pesoIdeal = 0;
        double IMC = persona1.getPeso() / (Math.pow(persona1.getAltura(), 2));
       // System.out.println(IMC);
        if (IMC < 20) {
            pesoIdeal = -1;
        } else {
            if (IMC > 25) {
                pesoIdeal = 1;

            }

        }

        return pesoIdeal;
    } 
    public void leerImc (int pesoIdeal) { 
           if (pesoIdeal == 0) {
            System.out.println("Usted está en su peso ideal");
        }else if (pesoIdeal== 1) {
            System.out.println("Usted tiene sobrepeso");
        }else {
            System.out.println("Ustede está por debajo de su peso ideal");
        }
}
}